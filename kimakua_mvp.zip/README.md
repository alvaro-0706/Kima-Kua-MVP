KIMA KUA — MVP (Public repository)

Author: Álvaro António
Admin (initial):
 - Nome: Álvaro António
 - E-mail: impossible.alvarito@gmail.com
 - Senha: Alvarito2004#

Resumo
------
Projeto MVP para a plataforma Kima Kua (conectar produtores a consumidores em Angola).
Este repositório contém duas pastas: `backend/` (Node.js + Express) e `frontend/` (React + Tailwind-ready).
Forneci scripts mínimos, um esquema SQL e instruções de deploy gratuitas (Railway/Vercel).

Estrutura
---------
/backend      -> API (Express)
/frontend     -> App (React)
/assets       -> logo e imagens
README.md
.env.example  -> variáveis de ambiente (backend)

Deploy rápido (Railway + Vercel)
--------------------------------
1) Backend (Railway - PostgreSQL)
 - Crie uma conta em https://railway.app
 - Crie um novo Project -> Deploy from GitHub (ou Upload)
 - Para testes locais use .env.example; no Railway defina DATABASE_URL com sua conexão Postgres.
 - Comando para iniciar localmente:
    cd backend
    npm install
    npm run dev

2) Frontend (Vercel or Netlify)
 - Suba a pasta frontend para o GitHub.
 - Conecte no Vercel (https://vercel.com) e aponte para o repositório.
 - No ambiente de Vercel, defina REACT_APP_API_URL para a URL do backend.

Observações
-----------
- O MVP inclui simulação de pagamento Multicaixa (placeholder). Para integrar a API real, substitua o handler em /backend/routes/payments.js.
- Integração WhatsApp tem placeholders; você precisará da conta WhatsApp Cloud API (Meta) e adicionar as chaves em .env.

Boa sorte — comece o deploy e me avise que eu te ajudo a apontar o domínio kimakua.com.