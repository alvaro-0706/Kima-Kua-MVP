const express = require('express');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// --- In-memory stores (MVP). Swap for DB in production.
let users = []; // {id,email,passwordHash,name,role}
let products = []; // {id,name,price,description,producerId,stock,image}
let orders = []; // {id,items:[{productId,qty}],buyerEmail,status}

app.get('/', (req, res) => res.json({ok:true, message: 'Kima Kua API (MVP)'}));

// Auth (simple, not production-ready)
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'troque_por_uma_chave_forte';

app.post('/api/auth/register', async (req, res) => {
  const {name, email, password, role} = req.body;
  if (!email || !password) return res.status(400).json({error:'email e password são obrigatórios'});
  if (users.find(u=>u.email===email)) return res.status(400).json({error:'usuario já existe'});
  const hash = await bcrypt.hash(password, 8);
  const user = {id: users.length+1, name, email, passwordHash: hash, role: role||'producer'};
  users.push(user);
  res.json({ok:true, user:{id:user.id, email:user.email, name:user.name, role:user.role}});
});

app.post('/api/auth/login', async (req, res) => {
  const {email, password} = req.body;
  const user = users.find(u=>u.email===email);
  if (!user) return res.status(400).json({error:'Credenciais inválidas'});
  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) return res.status(400).json({error:'Credenciais inválidas'});
  const token = jwt.sign({id:user.id, email:user.email, role:user.role}, JWT_SECRET, {expiresIn: '7d'});
  res.json({ok:true, token, user:{id:user.id, email:user.email, name:user.name, role:user.role}});
});

// Products
app.get('/api/products', (req,res)=> res.json(products));
app.post('/api/products', (req,res)=>{
  const p = req.body;
  p.id = products.length+1;
  products.push(p);
  res.json({ok:true, product:p});
});

// Orders
app.post('/api/orders', (req,res)=>{
  const o = req.body;
  o.id = orders.length+1;
  o.status = 'pending';
  orders.push(o);
  res.json({ok:true, order:o});
});
app.get('/api/orders', (req,res)=> res.json(orders));

// Payment simulation
app.post('/api/payments/multicaixa', (req,res)=>{
  // Simulação: retorna success sempre. Substituir por integração real.
  res.json({ok:true, status:'paid', provider:'multicaixa_sim'});
});

// WhatsApp placeholder
app.post('/api/notify/whatsapp', (req,res)=>{
  // placeholder: enviar mensagem via WhatsApp Cloud API
  console.log('WhatsApp notify (placeholder):', req.body);
  res.json({ok:true, message:'sent_mock'});
});

app.listen(PORT, ()=> console.log('Server running on', PORT));