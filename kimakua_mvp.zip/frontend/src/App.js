import React, {useEffect, useState} from 'react';
const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function App(){
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  useEffect(()=>{ fetch(API + '/api/products').then(r=>r.json()).then(setProducts).catch(()=>{}); },[]);
  const add = (p)=> setCart(prev=>[...prev,p]);
  const checkout = async ()=>{
    const order = { items: cart.map((c)=>({productId:c.id, qty:1})), buyerEmail: 'cliente@exemplo.com' };
    const res = await fetch(API + '/api/orders', {method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify(order)});
    const data = await res.json();
    alert('Pedido criado: ' + (data.order ? data.order.id : JSON.stringify(data)));
    setCart([]);
  };
  return (
    <div className="app">
      <header className="header">
        <img src="/logo.jpg" alt="Kima Kua" className="logo"/>
        <h1>Kima Kua</h1>
      </header>
      <main>
        <section className="products">
          <h2>Produtos</h2>
          {products.length===0 && <p>Nenhum produto (MVP). Você pode inserir produtos via API.</p>}
          <div className="grid">
            {products.map(p=>(
              <div className="card" key={p.id}>
                <img src={p.image || '/logo.jpg'} alt={p.name}/>
                <h3>{p.name}</h3>
                <p>{p.description}</p>
                <p><strong>{p.price}</strong></p>
                <button onClick={()=>add(p)}>Adicionar ao carrinho</button>
              </div>
            ))}
          </div>
        </section>
        <aside className="cart">
          <h3>Carrinho ({cart.length})</h3>
          <ul>
            {cart.map((c,idx)=>(<li key={idx}>{c.name || 'Produto'}</li>))}
          </ul>
          <button onClick={checkout} disabled={cart.length===0}>Finalizar compra (simulação)</button>
        </aside>
      </main>
      <footer>© Kima Kua — Conectando produtores a mercados em Angola</footer>
    </div>
  );
}

export default App;